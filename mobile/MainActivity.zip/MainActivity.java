package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText username,password,repassword;
Button btnsignup,btnsignin;
dbhelper mydb;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username=(EditText)findViewById(R.id.editTextText3);
        password=(EditText)findViewById(R.id.editTextText4);
        repassword=(EditText)findViewById(R.id.editTextText5);
        btnsignup=(Button)findViewById(R.id.button);
        btnsignin=(Button)findViewById(R.id.button2);
        mydb=new dbhelper(this);
        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user =username.getText().toString();
                String pass =password.getText().toString();
                String repass=repassword.getText().toString();
                if (user.equals("")|| pass.equals("")||repass.equals("")){
                    Toast.makeText(MainActivity.this,"fill all fields,please",Toast.LENGTH_SHORT).show();
                }
                else {
                    if(pass.equals(repass)){
                        boolean usercheckresult=mydb.checkusername(user);
                        if (usercheckresult==false){
                       boolean regresult=mydb.insertdata(user,pass);
                  if (regresult==true){
                      Toast.makeText(MainActivity.this,"registration is successful",Toast.LENGTH_SHORT).show();
                      Intent intent=new Intent(getApplicationContext(), loginactivity.class);
                      startActivity(intent);
                  }
                  else {
                      Toast.makeText(MainActivity.this,"registration has failed",Toast.LENGTH_SHORT).show();
                  }
                        }
                       else {
                            Toast.makeText(MainActivity.this,"user already exists, sign in ",Toast.LENGTH_SHORT).show();
                        }
                  }
else {
                        Toast.makeText(MainActivity.this,"passwords are not matching",Toast.LENGTH_SHORT).show();
                    }
                }
}
        });
        btnsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(), loginactivity.class);
                startActivity(intent);
           }
        });
    }
}