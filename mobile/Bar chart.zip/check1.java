package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;



public class check1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check1);
        BarChart barChart=findViewById(R.id.barchart);

        String[] labels = new String[]{"Jan", "Feb", "Mar", "Apr", "May","June","July","Aug","Sep","Oct","Nov","Dec"};

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new MyXAxisValueFormatter(labels));
        ArrayList<BarEntry>visitors=new ArrayList<>();
        visitors.add(new BarEntry(0,420));
        visitors.add(new BarEntry(1,430));
        visitors.add(new BarEntry(2,440));
        visitors.add(new BarEntry(3,450));
        visitors.add(new BarEntry(4,460));
        visitors.add(new BarEntry(5,470));
        visitors.add(new BarEntry(6,480));
        visitors.add(new BarEntry(7,490));
        visitors.add(new BarEntry(8,500));
        visitors.add(new BarEntry(9,510));
        visitors.add(new BarEntry(10,520));
        visitors.add(new BarEntry(11,530));


        BarDataSet barDataSet=new BarDataSet(visitors,"Farm's Irrigation");
        barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(17f);
        BarData barData=new BarData(barDataSet);
        barChart.setFitBars(true);
        barChart.setData(barData);
        barChart.getDescription().setText("Bar Chart");
        barChart.animateY(200);
    }
}