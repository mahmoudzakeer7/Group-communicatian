package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import java.util.ArrayList;
import java.util.Map;

public class check3 extends AppCompatActivity {
    LineChart lineChart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check3);

        lineChart=findViewById(R.id.linechart);
        LineDataSet lineDataSet=new LineDataSet(datavalues(),"Data set");
        ArrayList<ILineDataSet> dataSets=new ArrayList<>();
        dataSets.add(lineDataSet);
        LineData data=new LineData(dataSets);
        lineChart.setData(data);
        lineChart.invalidate();

    }
    private ArrayList<Entry>datavalues(){
        ArrayList<Entry> dataval=new ArrayList<Entry>();
        dataval.add(new Entry(0,20));
        dataval.add(new Entry(1,10));
        dataval.add(new Entry(2,30));
        dataval.add(new Entry(3,40));
        dataval.add(new Entry(4,50));
        return dataval;

    }
}