package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class check2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check2);
        BarChart barChart=findViewById(R.id.barchart);

        String[] labels = new String[]{"Jan", "Feb", "Mar", "Apr", "May","June","July","Aug","Sep","Oct","Nov","Dec"};

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new MyXAxisValueFormatter(labels));
        ArrayList<BarEntry> visitors=new ArrayList<>();
        visitors.add(new BarEntry(0,100));
        visitors.add(new BarEntry(1,150));
        visitors.add(new BarEntry(2,200));
        visitors.add(new BarEntry(3,250));
        visitors.add(new BarEntry(4,300));
        visitors.add(new BarEntry(5,350));
        visitors.add(new BarEntry(6,400));
        visitors.add(new BarEntry(7,450));
        visitors.add(new BarEntry(8,500));
        visitors.add(new BarEntry(9,550));
        visitors.add(new BarEntry(10,600));
        visitors.add(new BarEntry(11,650));


        BarDataSet barDataSet=new BarDataSet(visitors,"Farm's Firtilization");
        barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        barDataSet.setValueTextColor(Color.BLACK);
        barDataSet.setValueTextSize(16f);
        BarData barData=new BarData(barDataSet);
        barChart.setFitBars(true);
        barChart.setData(barData);
        barChart.getDescription().setText("Bar Chart");
        barChart.animateY(200);
    }
}